import React from 'react';
import { Alert } from 'react-native';
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import Login from '../app/(auth)/login';

jest.mock('@/components/BackButton', () => 'View');
jest.mock('@/components/ScreenWrapper', () => 'View');
jest.mock('@/components/Input', () => 'TextInput');
jest.mock('@/components/Button', () => 'Button');
jest.mock('@/components/Typo', () => 'Text');

jest.mock('expo-router', () => ({
  useRouter: () => ({
    replace: jest.fn(),
  }),
}));

const mockLogin = jest.fn();

jest.mock('@/context/authContext', () => ({
  useAuth: () => ({
    login: mockLogin,
  }),
}));

describe('Login Screen', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    jest.spyOn(Alert, 'alert').mockImplementation(() => {});
  });

  it('renderiza inputs y botón correctamente', () => {
    const { getByPlaceholderText, getByText } = render(<Login />);

    expect(getByPlaceholderText('Enter your email')).toBeTruthy();
    expect(getByPlaceholderText('Enter your password')).toBeTruthy();
    expect(getByText('Login')).toBeTruthy();
  });

  it('muestra alerta si los campos están vacíos', async () => {
    const { getByText } = render(<Login />);

    fireEvent.press(getByText('Login'));

    expect(Alert.alert).toHaveBeenCalledWith(
      'Login',
      'Please fill all the fields'
    );
  });

  it('llama a login si los datos son válidos', async () => {
    mockLogin.mockResolvedValue({ success: true });

    const { getByPlaceholderText, getByText } = render(<Login />);

    fireEvent.changeText(
      getByPlaceholderText('Enter your email'),
      'test@test.com'
    );

    fireEvent.changeText(
      getByPlaceholderText('Enter your password'),
      '12345678'
    );

    fireEvent.press(getByText('Login'));

    await waitFor(() => {
      expect(mockLogin).toHaveBeenCalledWith('test@test.com', '12345678');
    });
  });
});